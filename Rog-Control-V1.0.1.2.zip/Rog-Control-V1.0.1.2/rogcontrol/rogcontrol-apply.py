#!/usr/bin/env python3
"""
rogcontrol-apply.py
Reapplies your last-saved ROG Control profile plus independent settings
(keyboard brightness, charge limit, boot sound, panel overdrive, GPU
clock offsets) at login. Retries several times with delays, since some services
(nvidia, asus-wmi) may not be fully ready right at login.

--profile-only applies the profile and leaves the keyboard alone.

That flag exists because this script has two callers with two different
jobs. At login it is the whole of "put the machine back the way it was",
keyboard included. But the tray also runs it to make a profile switch real,
and a profile switch has no business touching the keyboard: keyboard
brightness is a GLOBAL setting -- there is one kbd_brightness in the config
and no profile has its own -- so re-applying it on every switch does not
express the new profile, it just overwrites whatever the keyboard is
currently doing with the last value written to the config. With
kbd_brightness at 0 that means the backlight goes out every time the user
picks a different profile, which is what they reported.

The charge limit is global in exactly the same way and IS still applied
here. The difference is who else writes it: the keyboard backlight is also
changed by the Fn keys, the kbdlight cycler and the ambient sampler, so a
stale config value fights the user. Nothing but this app ever writes the
charge threshold, so re-asserting it costs one helper call, changes nothing
the user can see, and covers the case where the EC has forgotten it -- and
a charge limit that has silently lapsed is invisible until the battery is
already damaged.

The boot sound is global on the same terms, and applied on the same terms:
nothing else on the machine writes it, the write is idempotent, and a chime
that has come back because a BIOS update reset the firmware is only heard at
the next power-on -- by which time nobody is looking at this app.

Panel overdrive is the third of these globals and is here for the same
reasons, with one of its own: the setting is a property of the screen, so
losing it is something the user sees all day and has no way to connect back
to the BIOS update that caused it.
"""

import os
import subprocess
import sys
import time
import traceback

# The shared modules sit beside this script's package in the repo, and under
# ~/.local/lib once installed -- this script is installed into ~/.local/bin,
# where there is no package next to it. Same probe the tray and the enforcer
# do, repo first so a checkout tests the checkout.
_HERE = os.path.dirname(os.path.abspath(__file__))
for _candidate in (os.path.dirname(_HERE), os.path.expanduser("~/.local/lib")):
    if os.path.isfile(os.path.join(_candidate, "rogcontrol", "__init__.py")):
        if _candidate not in sys.path:
            sys.path.insert(0, _candidate)
        break

from rogcontrol import config as config_mod  # noqa: E402
from rogcontrol import fancurve  # noqa: E402
from rogcontrol import hardware  # noqa: E402

# The curve maths and the helper call are the package's, not this script's.
# Both used to be copied in here verbatim -- interpolate_curve existed in
# four files and run_helper in seven -- which is how the silent-failure bug
# fixed in the enforcer survived here for another release.
interpolate_curve = fancurve.interpolate_curve
pct_to_pwm255 = fancurve.pct_to_pwm255


def run_helper(*args):
    """Run a privileged action and REPORT failure.

    The package's run_helper_logged with this script's name on it. The body
    used to live here, and identically in the cycler and the enforcer --
    which is the shape the silent-failure bug hid in the first time."""
    return hardware.run_helper_logged(*args, source="apply", timeout=30)[0]


def run_nvidia_helper(*args):
    """A helper write that goes through nvidia-smi.

    Same call, two differences that belong to the card rather than the value:
    a runtime-suspended card is given a moment to come back first, and "the
    card is not reachable" is logged at INFO rather than ERROR. Measured on
    2026-09-04: supergfxd unbound and removed the dGPU mid mode-switch, and
    the writes landing in that window put two red lines in the log for
    settings that were never wrong and are re-applied by the enforcer on its
    next pass."""
    return hardware.run_nvidia_helper_logged(
        *args, source="apply", timeout=30,
        wait_seconds=DGPU_WAKE_WAIT_SECONDS)[0]

# Every setting this machine has; the helper refuses anything it cannot
# do, and this script has no capability probe of its own. ryzenadj is the
# exception: it is asked about, because it does not refuse cleanly on a chip
# it cannot talk to -- on an Intel machine with the binary installed it
# fails, loudly, on every boot for a limit that was never applicable.
# cpu_power_limits is asked about for the same reason and covers Intel's
# ppt/RAPL backend too -- see hardware.cpu_power_limits_backend.
ALL_CPU_CAPS = {"ryzenadj": hardware.cpu_is_amd(), "cpu_boost": True,
                "cpu_epp": True, "cpu_clock": True,
                "cpu_power_limits": hardware.cpu_power_limits_backend()}

# The package's path, not a second spelling of the same string.
CONFIG_PATH = config_mod.CONFIG_PATH
RETRIES = 3
DELAY_SECONDS = 10

# How long a GPU write waits for a runtime-suspended card, for the same
# reason OFFSET_WAIT_SECONDS below exists: this script is one-shot, so a
# short wait is its only second chance. The enforcer passes 0 -- it must not
# sleep in its loop and gets a free retry a minute later.
DGPU_WAKE_WAIT_SECONDS = 5

# See pages/fans.py: retested down to 0.5s with no failures, kept at 5s for
# margin over the retested floor.
CHANNEL_GAP_S = 5



def _offset_worth_writing(gpu, key, profile_only):
    """Whether this clock offset has to be sent to the card at all.

    A profile switch always writes it: 0 there is a real instruction, the
    one that takes the previous profile's overclock back off.

    At login it is skipped when it is 0, because the card has just been
    initialised and every offset on it is 0 already -- so the write cannot
    change anything, and it costs an nvidia-settings launch (a second of
    it) per offset on every single boot. This is also the pair of calls that
    used to fail before the session had a display and put two ERROR lines in
    the log at every login for a write that would have been a no-op."""
    if key not in gpu:
        return False
    if profile_only:
        return True
    try:
        return int(gpu[key]) != 0
    except (TypeError, ValueError):
        return True


# How long the login apply may wait for the session to publish a display
# before giving up on an offset. This script is one-shot -- nothing behind it
# retries -- so unlike the enforcer it is worth waiting a little. Kept short
# all the same: the enforcer defers and retries the same offsets every 60
# seconds (see its retry_pending_gpu_offsets), so a session that takes longer
# than this, or that does not exist yet because nobody has logged in, still
# gets its overclock. This is a head start, not the safety net.
OFFSET_WAIT_SECONDS = 15


def _offset_failure_level(message):
    """ERROR for a real failure, INFO for the two "not yet" answers.

    Neither is this script's problem to report: the enforcer picks the offset
    up and applies it when the session appears, or when the card comes back
    from Integrated. Logging them as ERROR is what put two red lines in the
    log at every boot, and six more per graphics-mode switch, for work that
    was about to be handled."""
    return ("INFO"
            if message in (hardware.NO_DISPLAY_MESSAGE,
                           hardware.NO_DRIVER_MESSAGE)
            else "ERROR")


def apply_gpu_clock_offsets(gpu, profile_only=False):
    # Through hardware.set_nvidia_clock_offset, not a hand-built command
    # line. Both copies of this ran nvidia-settings with NO timeout, in a
    # service that is a single loop: one hung call and the enforcer stops
    # enforcing anything, for good, with nothing logged -- and on the
    # auto-switch path it hangs while holding _ac_lock. The package's call
    # has a timeout and turns a failure into (ok, message) rather than an
    # exception, which is what every other subprocess in this tree does.
    if _offset_worth_writing(gpu, "clock_offset", profile_only):
        ok, message = hardware.set_nvidia_clock_offset(
            "core", gpu["clock_offset"], wait_seconds=OFFSET_WAIT_SECONDS)
        if not ok:
            hardware.log(f"GPU core clock offset failed: {message}",
                         _offset_failure_level(message), source="apply",
                         dedupe_key="nvcore")
    if "clock_limit" in gpu:
        # Against the card's own maximum, not a hardcoded 3090: the top of
        # the slider means "no ceiling", and comparing against another
        # card's number turns that into a lock (or refuses a real cap).
        run_nvidia_helper("gpuclocklimit",
                          hardware.gpu_clock_limit_arg(
                              gpu["clock_limit"],
                              hardware.gpu_clock_limit_max()))
    if "dyn_boost" in gpu:
        run_helper("nvboost", gpu["dyn_boost"])
    if "temp_target" in gpu:
        run_helper("nvtemp", gpu["temp_target"])
    if _offset_worth_writing(gpu, "mem_clock_offset", profile_only):
        ok, message = hardware.set_nvidia_clock_offset(
            "memory", gpu["mem_clock_offset"],
            wait_seconds=OFFSET_WAIT_SECONDS)
        if not ok:
            hardware.log(f"GPU memory clock offset failed: {message}",
                         _offset_failure_level(message), source="apply",
                         dedupe_key="nvmem")


def apply_once(config, profile_only=False, force_stock_undervolt=False):
    profile_name = config.get("current_profile")
    profile = config.get("profiles", {}).get(profile_name)

    # First, before anything else is written. This script is what the tray
    # runs to make a profile switch real, and without it the tray switched
    # the profile while leaving power-profiles-daemon on the old mode -- so
    # the enforcer read the disagreement as the OS asking for the old
    # profile, switched back within a minute and re-pushed all three fan
    # curves to do it. It also has to come before the fan writes: changing
    # the mode is what makes the EC drop the custom curve, so a curve
    # written first is handed to a controller about to throw it away.
    #
    # A profile that maps to no OS mode returns None and changes nothing.
    hardware.set_power_mode_for_profile(profile_name)

    # And the keyboard colour, if the user has put the keyboard on the
    # profile. Unlike kbd_brightness below this is NOT skipped for
    # --profile-only, and the difference is the whole point: the brightness
    # is global, so re-asserting it on a switch overwrites whatever the Fn
    # keys last did. The colour belongs TO the profile, so a switch that did
    # not write it would leave the keys wearing the profile the user has
    # just left. Returns None, writing nothing, on any other lighting mode.
    hardware.set_profile_kbd_color(config, profile_name)

    if profile:
        cpu = profile.get("cpu")
        if cpu:
            # One definition of what a CPU apply writes and in what order,
            # shared with the window and the enforcer. It used to be a chain
            # of ifs here as well, and every setting added since has had to
            # be added to each copy by hand -- the clock floor reached three
            # of the four and was silently dropped by the fourth.
            #
            # force_stock_undervolt is the crash-loop breaker: two boots in a
            # row with no proof the current coall is safe (see
            # config.record_boot_attempt) and this profile's own value is
            # not sent, only stock, until the user clears it from the CPU
            # page. Everything else in the profile -- power limits, boost,
            # clock -- still applies normally; those are not what freezes a
            # machine.
            cpu_to_apply = (config_mod.stock_cpu_values(cpu)
                           if force_stock_undervolt else cpu)
            for _step, args in hardware.cpu_apply_plan(cpu_to_apply, ALL_CPU_CAPS):
                run_helper(*args)
        gpu = profile.get("gpu")
        if gpu and hardware.dgpu_available():
            # "watts" asked for rather than assumed. A profile whose gpu
            # section is present but empty -- hand-edited, or imported from a
            # file that only carried part of one -- raised KeyError here, and
            # the whole apply is wrapped in `except Exception: pass`, so the
            # crash silently took the charge limit, the boot chime and the
            # panel overdrive below it down as well. The window has always
            # guarded this; the three background copies did not.
            if "watts" in gpu:
                run_nvidia_helper("gpu", gpu["watts"])
            apply_gpu_clock_offsets(gpu, profile_only=profile_only)

        # Only the channels whose curve is not already the one the
        # controller is running. Each write costs a CHANNEL_GAP_S gap before
        # the next, so a switch back to a profile whose fans match costs
        # nothing instead of ten seconds. Read from the driver rather than
        # remembered: the EC drops curves behind this app's back on every
        # power-mode change, and a channel it has thrown away has to be
        # rewritten even though nothing in the config moved.
        wanted = profile.get("fans", {})
        # Not while a fan boost is running. The System page's boost is a
        # deadline on disk that the enforcer maintains and ends (see
        # hardware.FAN_BOOST_STATE_PATH); writing the profile's curves over
        # it here -- this script is what the tray runs on a profile switch --
        # would have the enforcer push the flat curve straight back on its
        # next pass, and the fans would flip between the two for the rest of
        # the hold. The boost expires on its own, and the curves below go on
        # at that point.
        if hardware.fan_boost_active(hardware.read_fan_boost()):
            wanted = {}
        held = {ch: hardware.read_fan_curve_points(ch) for ch in wanted}
        enabled = hardware.read_fan_curve_enabled()
        todo = [(ch, pts) for ch, pts in wanted.items()
                if not (enabled.get(ch) is not False
                        and held.get(ch) is not None
                        and fancurve.curve_matches_hardware(pts, held[ch]))]
        for i, (channel, points) in enumerate(todo):
            if i > 0:
                # See pages/fans.py module docstring: 0.5s was first found
                # to leave channels stuck, but a later retest found 0.5s-8s
                # all held. CHANNEL_GAP_S is kept above the retested floor.
                time.sleep(CHANNEL_GAP_S)
            expanded = interpolate_curve(points, 8)
            flat = []
            for t, pct in expanded:
                flat += [t, pct_to_pwm255(pct)]
            hardware.run_fan_helper_logged(channel, *flat, source="apply")

    # Global settings, below the profile because neither belongs to one.
    # See the module docstring for why only one of them is skipped on a
    # profile switch.
    if "kbd_brightness" in config and not profile_only:
        run_helper("kbd", config["kbd_brightness"])
    if "charge_limit" in config:
        run_helper("charge", config["charge_limit"])
    # Absent means the user has never set it, so the firmware's own value is
    # left alone -- there is no sensible default to assert over a setting
    # that lives in the firmware and that this app did not choose. Once set,
    # it is re-asserted here so a firmware reset (or a BIOS update, which
    # returns it to the ASUS default) does not silently bring the chime back.
    if "boot_sound" in config:
        run_helper("bootsound", 1 if config["boot_sound"] else 0)
    # Panel overdrive is global on the same terms and re-asserted on the
    # same terms. It matters slightly more than the chime does: a firmware
    # reset that loses the chime is heard once at the next power-on, while a
    # firmware reset that loses overdrive leaves the user staring at a
    # smearier screen with nothing to tell them why. Absent from the config
    # still means "never set", and the firmware's own value is left alone.
    if "panel_od" in config:
        run_helper("panelod", 1 if config["panel_od"] else 0)


def _spawn_survival_watchdog():
    """Start a detached process that marks this boot as proven safe once it
    has run for config.BOOT_SURVIVAL_SECONDS without freezing.

    Detached, not a thread: this script's own retries finish in well under
    a minute, long before that mark is reached, and a thread dies with its
    process. start_new_session=True keeps it running after this process
    exits and out of the login apply's own process group, so nothing about
    login waits on it or can kill it by accident."""
    try:
        subprocess.Popen(
            [sys.executable, os.path.abspath(__file__),
             "--survival-watchdog"],
            start_new_session=True, stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as e:
        hardware.log(f"could not start the boot-survival watchdog: {e}",
                     "ERROR", source="apply", dedupe_key="watchdogspawn")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--survival-watchdog" in argv:
        # Not part of a login apply -- see _spawn_survival_watchdog. Sleeps
        # past the point a crash-loop's next freeze would usually already
        # have happened, then clears the streak that record_boot_attempt
        # keeps. If this process itself gets killed by a freeze, it simply
        # never reaches the write, which is exactly the "unproven" state
        # the counter is meant to stay in.
        time.sleep(config_mod.BOOT_SURVIVAL_SECONDS)
        config_mod.mark_boot_survived()
        return
    profile_only = "--profile-only" in argv
    if not os.path.exists(CONFIG_PATH):
        return
    # The crash-loop breaker only applies to a real login apply. A profile
    # switch (--profile-only) runs on a machine already known to be up, so
    # it has nothing to do with a boot that never got that far, and counting
    # it as a "boot" would let the user's own profile switches paper over an
    # undervolt that is actually the problem.
    force_stock_undervolt = False
    if not profile_only:
        cfg = config_mod.load_config()
        force_stock_undervolt = config_mod.record_boot_attempt(cfg)
        # Written now, before the risky write below, not after this
        # function returns -- see record_boot_attempt's docstring.
        config_mod.save_config(cfg)
        _spawn_survival_watchdog()
    # The retries are for login, and only for login. At login nvidia and
    # asus-wmi may not have finished coming up, so the whole apply is run
    # three times ten seconds apart and the last one wins.
    #
    # A profile switch is the other caller, and there the retries were pure
    # cost: the machine is already up, nothing is going to become ready, and
    # the loop ran the entire apply -- sixteen seconds of fan writes included
    # -- three times with two ten second sleeps in between. Measured at 69
    # seconds for a switch that has 16 seconds of work in it.
    attempts = 1 if profile_only else RETRIES
    for attempt in range(attempts):
        try:
            # config.load_config, not a bare json.load: a config that will
            # not parse used to raise here and take the whole login apply
            # down with it, silently and on every boot after. load_config
            # keeps the unreadable file as a .corrupt-<timestamp> copy and
            # hands back a migrated default, so the machine at least comes up
            # configured.
            apply_once(config_mod.load_config(), profile_only=profile_only,
                      force_stock_undervolt=force_stock_undervolt)
        except Exception as e:  # noqa: BLE001 - logged, then retried
            # Logged rather than swallowed. This runs at login with nothing
            # on screen: a broken config, a missing dependency or a bug in
            # apply_once left no trace anywhere at all -- not even in the log
            # this app tells users to check -- so "my profile did not come
            # back after a reboot" had nothing to go on. Every other script
            # in this tree logs its unexpected exceptions; this one did not.
            hardware.log(f"apply failed: {e}", "ERROR", source="apply",
                         dedupe_key="applyfail")
            traceback.print_exc()
        if attempt < attempts - 1:
            time.sleep(DELAY_SECONDS)


if __name__ == "__main__":
    main()
